package com.rathor.hci.items;

/**
 * Created by Harikesh on 3/9/2017.
 */
public class Interest {
    private String interest;

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }
}
