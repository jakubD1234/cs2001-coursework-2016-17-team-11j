package com.rathor.hci.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.rathor.hci.R;
import com.rathor.hci.utils.AppSession;

public class TopicAcitivity extends AppCompatActivity {

    private AppSession mSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic_acitivity);
        mSession = AppSession.getInstance(getApplicationContext());

        RadioGroup rg = (RadioGroup) findViewById(R.id.radioGroup);
        findViewById(R.id.choose_ownBt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(TopicAcitivity.this);

                final EditText edittext = new EditText(TopicAcitivity.this);
                //alert.setMessage("Please type your interested topic");
                alert.setTitle("Please Enter Your Own Topic");

                alert.setView(edittext);

                alert.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        String YouEditTextValue = edittext.getText().toString();
                        if (!YouEditTextValue.equals("")) {
                            callIntent();
                            //Toast.makeText(TopicAcitivity.this, "Selected " + YouEditTextValue, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(TopicAcitivity.this, "Enter topic field should not be empty" + YouEditTextValue, Toast.LENGTH_LONG).show();

                        }
                    }
                });

                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        // what ever you want to do with No option.
                    }
                });

                alert.show();
            }
        });


        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radioButton:
                        callIntent();
                        Toast.makeText(TopicAcitivity.this, "Selected Current Affairs", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton2:
                        callIntent();
                        Toast.makeText(TopicAcitivity.this, "Selected Favourite Food", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton3:
                        callIntent();
                        Toast.makeText(TopicAcitivity.this, "Selected Travelling", Toast.LENGTH_LONG).show();
                        break;
                }
            }
        });
    }

    private void callIntent() {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        //intent.putExtra("redirectType","login");
        mSession.setRedirectType("login");
        mSession.setHasLoging(true);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

}
