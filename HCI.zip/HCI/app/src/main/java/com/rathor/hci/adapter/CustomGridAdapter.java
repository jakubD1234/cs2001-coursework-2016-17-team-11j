package com.rathor.hci.adapter;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.rathor.hci.R;
import com.rathor.hci.fragment.FragIntersets;
import com.rathor.hci.items.Item;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Created by gigabyte on 06-12-2016.
 */

public class CustomGridAdapter extends BaseAdapter {
    private final FragIntersets mContextFrag;
    public final ArrayList<Item> listItem;
    private Context mContext;
    /* public final String[] web;
     private final int[] Imageid;*/
    public HashMap<Integer, Boolean> mSelectedList = new HashMap<>();
    public int mSelectedCount = 0;

   /* public CustomGridAdapter(Context c, FragIntersets fragIntersets, String[] web, int[] Imageid) {
        mContext = c;
        mContextFrag = fragIntersets;
        this.Imageid = Imageid;
        this.web = web;
        for (int i = 0; i < web.length; i++) {
            mSelectedList.put(i, false);
        }
    }*/

    public CustomGridAdapter(FragmentActivity activity, FragIntersets fragIntersets, ArrayList<Item> listItems) {
        mContext = activity;
        mContextFrag = fragIntersets;
        this.listItem = listItems;
        for (int i = 0; i < listItems.size(); i++) {
            mSelectedList.put(i, false);
        }
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return mSelectedList.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        View grid;
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final Item item = listItem.get(position);
        grid = inflater.inflate(R.layout.grid_single, null);
        TextView textView = (TextView) grid.findViewById(R.id.grid_text);
        final ImageView imageView = (ImageView) grid.findViewById(R.id.grid_image);
        textView.setText(item.getWeb());
        // imageView.setImageResource(item.getImageId());
        Picasso.with(mContext)
                .load(item.getImageId())
                .into(imageView);

        if (mSelectedList.get(position) == true) {
            imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.toolbar_color));
        } else {
            imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.tranparent_color));
        }

        grid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mSelectedList.get(position) == true) {
                    mSelectedList.put(position, false);
                    mSelectedCount = mSelectedCount - 1;
                    imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.light_yellow));
                    mContextFrag.addInterest(item.getWeb(), true, position);
                    mContextFrag.updateButtonStatus(mSelectedCount);


                } else {
                    imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.tranparent_color));
                    mSelectedList.put(position, true);
                    mSelectedCount = mSelectedCount + 1;
                    mContextFrag.addInterest(item.getWeb(), false, position);
                    mContextFrag.updateButtonStatus(mSelectedCount);


                }
                notifyDataSetChanged();
            }
        });
        return grid;
    }

    public void updateList() {
       /* listItem.clear();
        listItem.addAll(list);*/
        for (int i = 0; i < listItem.size(); i++) {
            mSelectedList.put(i, false);
        }
        notifyDataSetChanged();

    }
}