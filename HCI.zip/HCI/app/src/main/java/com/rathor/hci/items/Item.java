package com.rathor.hci.items;

/**
 * Created by Harikesh on 3/13/2017.
 */
public class Item {
    String web;
    int imageId;

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
}
